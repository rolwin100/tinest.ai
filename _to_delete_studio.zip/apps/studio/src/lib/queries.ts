import { queryOptions } from '@tanstack/react-query'

import { fetchCaps } from '#/lib/tts'

export const capsQuery = queryOptions({
  queryKey: ['tts', 'caps'],
  queryFn: fetchCaps,
  // The voice table hot-reloads server-side when voices.yaml changes;
  // refetching on focus keeps the edit-listen loop honest without polling.
  refetchOnWindowFocus: true,
  staleTime: 30_000,
  retry: 1,
})
