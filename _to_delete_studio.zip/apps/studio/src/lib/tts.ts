/**
 * Client for the gotiny TTS wire protocol v1 (see packages/gotiny-providers wire.py).
 *
 * WS /v1/tts:stream:
 *   client → one JSON header frame  { request_id, text, voice_id, language, sample_rate, speed }
 *   server → raw binary frames      PCM s16le mono, sentence-chunked
 *   server → one JSON trailer       { request_id, done, ttfb_ms, audio_ms, chars, provider }
 *   server → (instead of trailer)   { request_id, error, kind } when synthesis cannot proceed
 *   client → { cancel: request_id } barge-in: drop remaining sentences
 *
 * Reference audio never travels in a request — voice_id is a stable logical name
 * the server resolves (ADR 0004).
 */

export const SAMPLE_RATE = 24_000

/** Same-origin in dev; Vite proxies /api/tts → the TTS server (see vite.config.ts). */
export function ttsHttpBase(): string {
  return '/api/tts'
}

function ttsWsUrl(): string {
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  return `${proto}://${window.location.host}/api/tts/v1/tts:stream`
}

// ── caps / voices ──

export interface VoiceSpec {
  voice_id: string
  backend: string
  voice: string
  language: string
  grade: string | null
  note: string | null
}

export interface BackendCaps {
  name: string
  modality: string
  languages: Array<string>
  sample_rates: Array<number>
  streaming: boolean
  supports_cloning: boolean
  chunk_granularity: string
}

export interface Caps {
  wire: string
  backends: Array<BackendCaps>
  voices: Array<VoiceSpec>
}

export async function fetchCaps(): Promise<Caps> {
  const res = await fetch(`${ttsHttpBase()}/v1/caps`)
  if (!res.ok) {
    throw new Error(
      `TTS server unreachable (${res.status}). Start it with \`just tts\` and reload.`,
    )
  }
  return res.json() as Promise<Caps>
}

// ── wire frames ──

export interface TTSTrailer {
  request_id: string
  done: boolean
  ttfb_ms: number
  audio_ms: number
  chars: number
  provider: string
}

export interface TTSErrorFrame {
  request_id: string
  error: string
  kind: 'unsupported_language' | 'unsupported_capability' | 'unknown_voice' | 'internal'
}

export interface SynthesisRequest {
  text: string
  voiceId: string
  language: string
  speed: number
}

export interface SynthesisResult {
  trailer: TTSTrailer
  /** Client-measured time to first audio byte, network included. */
  clientTtfbMs: number
  cancelled: boolean
}

export class TTSWireError extends Error {
  kind: TTSErrorFrame['kind']
  constructor(frame: TTSErrorFrame) {
    super(frame.error)
    this.kind = frame.kind
  }
}

/**
 * Plays streamed PCM s16le mono chunks gaplessly via Web Audio, by scheduling
 * each chunk as an AudioBufferSourceNode at the exact time the previous one ends.
 */
class PcmPlayer {
  private ctx: AudioContext
  private nextAt = 0
  private sources = new Set<AudioBufferSourceNode>()

  constructor(sampleRate: number) {
    this.ctx = new AudioContext({ sampleRate })
  }

  async resume(): Promise<void> {
    if (this.ctx.state === 'suspended') await this.ctx.resume()
  }

  enqueue(chunk: ArrayBuffer): void {
    const int16 = new Int16Array(chunk)
    if (int16.length === 0) return
    const float32 = new Float32Array(int16.length)
    for (let i = 0; i < int16.length; i++) float32[i] = int16[i] / 32768
    const buffer = this.ctx.createBuffer(1, float32.length, this.ctx.sampleRate)
    buffer.copyToChannel(float32, 0)
    const source = this.ctx.createBufferSource()
    source.buffer = buffer
    source.connect(this.ctx.destination)
    const now = this.ctx.currentTime
    // Small initial lead-in so the first chunk doesn't start in the past.
    const at = Math.max(this.nextAt, now + 0.05)
    source.start(at)
    this.nextAt = at + buffer.duration
    this.sources.add(source)
    source.onended = () => this.sources.delete(source)
  }

  /** Seconds until everything already enqueued has finished playing. */
  remaining(): number {
    return Math.max(0, this.nextAt - this.ctx.currentTime)
  }

  stop(): void {
    for (const s of this.sources) {
      try {
        s.stop()
      } catch {
        /* already stopped */
      }
    }
    this.sources.clear()
    this.nextAt = 0
  }

  async close(): Promise<void> {
    this.stop()
    if (this.ctx.state !== 'closed') await this.ctx.close()
  }
}

export interface SynthesisHandle {
  /** Resolves when the trailer arrives (audio may still be playing). */
  done: Promise<SynthesisResult>
  /** Barge-in: server drops remaining sentences; local playback stops. */
  cancel: () => void
}

/**
 * Open one synthesis stream and play it as it arrives.
 * One WS connection per request, mirroring the server's handle_stream.
 */
export function synthesize(
  req: SynthesisRequest,
  opts: { onFirstAudio?: () => void } = {},
): SynthesisHandle {
  const requestId = crypto.randomUUID()
  const player = new PcmPlayer(SAMPLE_RATE)
  const ws = new WebSocket(ttsWsUrl())
  ws.binaryType = 'arraybuffer'

  let cancelled = false
  let settled = false
  const t0 = performance.now()
  let clientTtfbMs = 0

  const done = new Promise<SynthesisResult>((resolve, reject) => {
    const settle = (fn: () => void) => {
      if (settled) return
      settled = true
      fn()
    }

    ws.onopen = () => {
      void player.resume()
      ws.send(
        JSON.stringify({
          request_id: requestId,
          text: req.text,
          voice_id: req.voiceId,
          language: req.language,
          sample_rate: SAMPLE_RATE,
          speed: req.speed,
        }),
      )
    }

    ws.onmessage = (event: MessageEvent<ArrayBuffer | string>) => {
      if (typeof event.data !== 'string') {
        if (clientTtfbMs === 0) {
          clientTtfbMs = performance.now() - t0
          opts.onFirstAudio?.()
        }
        if (!cancelled) player.enqueue(event.data)
        return
      }
      const frame = JSON.parse(event.data) as TTSTrailer | TTSErrorFrame
      if ('error' in frame) {
        void player.close()
        ws.close()
        settle(() => reject(new TTSWireError(frame)))
        return
      }
      // Trailer: let the tail of the audio finish before closing the context.
      const tailMs = player.remaining() * 1000
      window.setTimeout(() => void player.close(), tailMs + 250)
      ws.close()
      settle(() => resolve({ trailer: frame, clientTtfbMs, cancelled }))
    }

    ws.onerror = () => {
      void player.close()
      settle(() =>
        reject(new Error('Could not reach the TTS server. Is `just tts` running?')),
      )
    }

    ws.onclose = () => {
      settle(() => reject(new Error('TTS stream closed before a trailer arrived.')))
    }
  })

  const cancel = () => {
    if (cancelled || settled) return
    cancelled = true
    player.stop()
    void player.close()
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ cancel: requestId }))
    }
  }

  return { done, cancel }
}
