import { useRef, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { GripVertical, Play, Plus, Square, Trash2 } from 'lucide-react'

import { Badge } from '#/components/ui/badge'
import { Button } from '#/components/ui/button'
import { Card, CardContent } from '#/components/ui/card'
import { Textarea } from '#/components/ui/textarea'
import { VoicePicker } from '#/components/voice-picker'
import { capsQuery } from '#/lib/queries'
import { synthesize } from '#/lib/tts'

import type { SynthesisHandle } from '#/lib/tts'

export const Route = createFileRoute('/episodes')({ component: Episodes })

interface Block {
  id: string
  voiceId: string | undefined
  text: string
}

const newBlock = (voiceId?: string): Block => ({
  id: crypto.randomUUID(),
  voiceId,
  text: '',
})

function Episodes() {
  const caps = useQuery(capsQuery)
  const voices = caps.data?.voices ?? []
  const [blocks, setBlocks] = useState<Array<Block>>(() => [newBlock()])
  const [playingId, setPlayingId] = useState<string | null>(null)
  const handleRef = useRef<SynthesisHandle | null>(null)

  const update = (id: string, patch: Partial<Block>) =>
    setBlocks((bs) => bs.map((b) => (b.id === id ? { ...b, ...patch } : b)))
  const remove = (id: string) => setBlocks((bs) => bs.filter((b) => b.id !== id))
  const add = () => setBlocks((bs) => [...bs, newBlock(bs.at(-1)?.voiceId)])

  const preview = (block: Block) => {
    const voice = voices.find((v) => v.voice_id === block.voiceId)
    if (!voice || !block.text.trim()) return
    handleRef.current?.cancel()
    setPlayingId(block.id)
    const handle = synthesize({
      text: block.text,
      voiceId: voice.voice_id,
      language: voice.language,
      speed: 1.0,
    })
    handleRef.current = handle
    handle.done.finally(() => setPlayingId((cur) => (cur === block.id ? null : cur)))
  }

  const stop = () => {
    handleRef.current?.cancel()
    setPlayingId(null)
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Episodes</h1>
          <p className="text-muted-foreground text-sm">
            Write a script as blocks, one voice per block. Preview any block live.
          </p>
        </div>
        <Button disabled variant="secondary" title="The render pipeline lands in week B">
          Render episode
          <Badge variant="outline" className="ml-1">
            soon
          </Badge>
        </Button>
      </div>

      <div className="flex flex-col gap-3">
        {blocks.map((block, i) => (
          <Card key={block.id}>
            <CardContent className="flex gap-3">
              <div className="text-muted-foreground flex flex-col items-center gap-1 pt-2">
                <GripVertical className="size-4" />
                <span className="text-xs">{i + 1}</span>
              </div>
              <div className="flex min-w-0 grow flex-col gap-2">
                <div className="flex items-center gap-2">
                  <VoicePicker
                    voices={voices}
                    value={block.voiceId}
                    onChange={(voiceId) => update(block.id, { voiceId })}
                    className="w-[260px]"
                  />
                  {playingId === block.id ? (
                    <Button size="sm" variant="destructive" onClick={stop}>
                      <Square /> Stop
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => preview(block)}
                      disabled={!block.voiceId || !block.text.trim()}
                    >
                      <Play /> Preview
                    </Button>
                  )}
                  <Button
                    size="icon"
                    variant="ghost"
                    className="ml-auto"
                    onClick={() => remove(block.id)}
                    disabled={blocks.length === 1}
                    aria-label="Remove block"
                  >
                    <Trash2 />
                  </Button>
                </div>
                <Textarea
                  value={block.text}
                  onChange={(e) => update(block.id, { text: e.target.value })}
                  rows={3}
                  placeholder="What this speaker says…"
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div>
        <Button variant="outline" onClick={add}>
          <Plus /> Add block
        </Button>
      </div>
    </div>
  )
}
