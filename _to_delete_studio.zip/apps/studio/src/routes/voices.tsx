import { useEffect, useRef, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { Mic, Square, Upload } from 'lucide-react'

import { Badge } from '#/components/ui/badge'
import { Button } from '#/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '#/components/ui/card'
import { Input } from '#/components/ui/input'
import { Label } from '#/components/ui/label'
import { capsQuery } from '#/lib/queries'

export const Route = createFileRoute('/voices')({ component: Voices })

function Voices() {
  const caps = useQuery(capsQuery)
  const voices = caps.data?.voices ?? []
  const cloningServed = caps.data?.backends.some((b) => b.supports_cloning) ?? false

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-2xl font-semibold">Voices</h1>
        <p className="text-muted-foreground text-sm">
          The voice library this server can speak, and (soon) your own cloned voice.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {voices.map((v) => (
          <Card key={v.voice_id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {v.voice_id}
                {v.grade ? (
                  <Badge variant={v.grade === 'A' ? 'default' : 'secondary'}>grade {v.grade}</Badge>
                ) : null}
              </CardTitle>
              <CardDescription>
                {v.language} · {v.backend}
              </CardDescription>
            </CardHeader>
            {v.note ? (
              <CardContent className="text-muted-foreground text-xs">{v.note}</CardContent>
            ) : null}
          </Card>
        ))}
      </div>

      <CloneStudio cloningServed={cloningServed} />
    </div>
  )
}

/**
 * UI shell for voice-cloning enrollment. Recording and upload work; submission
 * is disabled until the enrollment pipeline (worker job: quality gate → ASR
 * transcript → consent check → register) lands in week C.
 */
function CloneStudio({ cloningServed }: { cloningServed: boolean }) {
  const [recording, setRecording] = useState(false)
  const [sample, setSample] = useState<{ url: string; label: string } | null>(null)
  const [seconds, setSeconds] = useState(0)
  const recorderRef = useRef<MediaRecorder | null>(null)
  const timerRef = useRef<number | null>(null)

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current)
      recorderRef.current?.stream.getTracks().forEach((t) => t.stop())
      if (sample) URL.revokeObjectURL(sample.url)
    }
    // Cleanup on unmount only — `sample` is intentionally not a dependency.
  }, [])

  const start = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    const recorder = new MediaRecorder(stream)
    const chunks: Array<Blob> = []
    recorder.ondataavailable = (e) => chunks.push(e.data)
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: recorder.mimeType })
      setSample((prev) => {
        if (prev) URL.revokeObjectURL(prev.url)
        return { url: URL.createObjectURL(blob), label: 'recorded sample' }
      })
      stream.getTracks().forEach((t) => t.stop())
    }
    recorderRef.current = recorder
    recorder.start()
    setSeconds(0)
    setRecording(true)
    timerRef.current = window.setInterval(() => setSeconds((s) => s + 1), 1000)
  }

  const stop = () => {
    recorderRef.current?.stop()
    setRecording(false)
    if (timerRef.current) window.clearInterval(timerRef.current)
  }

  const onUpload = (file: File | undefined) => {
    if (!file) return
    setSample((prev) => {
      if (prev) URL.revokeObjectURL(prev.url)
      return { url: URL.createObjectURL(file), label: file.name }
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Clone your voice</CardTitle>
        <CardDescription>
          Record or upload ~2 minutes of your voice. Enrollment (quality check, transcript,
          consent) arrives in week C{cloningServed ? '' : ' — and no loaded backend supports cloning yet'}.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {recording ? (
            <Button variant="destructive" onClick={stop}>
              <Square /> Stop ({seconds}s)
            </Button>
          ) : (
            <Button variant="outline" onClick={() => void start()}>
              <Mic /> Record sample
            </Button>
          )}
          <div className="flex items-center gap-2">
            <Label htmlFor="sample-upload" className="sr-only">
              Upload a sample
            </Label>
            <Upload className="text-muted-foreground size-4" />
            <Input
              id="sample-upload"
              type="file"
              accept="audio/*"
              className="w-64"
              onChange={(e) => onUpload(e.target.files?.[0])}
            />
          </div>
        </div>
        {sample ? (
          <div className="flex items-center gap-3">
            <audio controls src={sample.url} className="h-9" />
            <span className="text-muted-foreground text-xs">{sample.label}</span>
          </div>
        ) : null}
        <div>
          <Button disabled title="Enrollment lands in week C">
            Create voice
            <Badge variant="outline" className="ml-1">
              soon
            </Badge>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
