import { useEffect, useRef, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { Loader2, Play, Square } from 'lucide-react'

import { Button } from '#/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '#/components/ui/card'
import { Label } from '#/components/ui/label'
import { Slider } from '#/components/ui/slider'
import { Textarea } from '#/components/ui/textarea'
import { VoicePicker } from '#/components/voice-picker'
import { capsQuery } from '#/lib/queries'
import { synthesize } from '#/lib/tts'

import type { SynthesisHandle, SynthesisResult } from '#/lib/tts'

export const Route = createFileRoute('/')({ component: Playground })

const DEFAULT_TEXT =
  'Welcome to gotiny studio. Type anything here, pick a voice, and press play to hear it.'

type Status =
  | { state: 'idle' }
  | { state: 'connecting' }
  | { state: 'playing' }
  | { state: 'done'; result: SynthesisResult }
  | { state: 'error'; message: string }

function Playground() {
  const caps = useQuery(capsQuery)
  const [voiceId, setVoiceId] = useState<string>()
  const [text, setText] = useState(DEFAULT_TEXT)
  const [speed, setSpeed] = useState(1.0)
  const [status, setStatus] = useState<Status>({ state: 'idle' })
  const handleRef = useRef<SynthesisHandle | null>(null)

  const voices = caps.data?.voices ?? []
  const voice = voices.find((v) => v.voice_id === voiceId)

  // Default to the first A-grade voice once caps arrive.
  useEffect(() => {
    if (!voiceId && voices.length > 0) {
      const preferred = voices.find((v) => v.grade === 'A') ?? voices[0]
      setVoiceId(preferred.voice_id)
    }
  }, [voices, voiceId])

  const busy = status.state === 'connecting' || status.state === 'playing'

  const play = () => {
    if (!voice || busy) return
    setStatus({ state: 'connecting' })
    const handle = synthesize(
      { text, voiceId: voice.voice_id, language: voice.language, speed },
      { onFirstAudio: () => setStatus({ state: 'playing' }) },
    )
    handleRef.current = handle
    handle.done
      .then((result) => setStatus({ state: 'done', result }))
      .catch((e: unknown) =>
        setStatus({ state: 'error', message: e instanceof Error ? e.message : String(e) }),
      )
  }

  const stop = () => handleRef.current?.cancel()

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold">Playground</h1>
        <p className="text-muted-foreground text-sm">
          Live synthesis over the wire protocol — the same path a rendered episode takes.
        </p>
      </div>

      {caps.isError ? (
        <Card className="border-destructive/50">
          <CardHeader>
            <CardTitle>TTS server unreachable</CardTitle>
            <CardDescription>{caps.error.message}</CardDescription>
          </CardHeader>
        </Card>
      ) : null}

      <Card>
        <CardContent className="flex flex-col gap-4">
          <div className="grid gap-4 sm:grid-cols-[1fr_220px]">
            <div className="flex flex-col gap-2">
              <Label htmlFor="script">Text</Label>
              <Textarea
                id="script"
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={5}
                placeholder="Type something to say…"
              />
            </div>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2">
                <Label>Voice</Label>
                <VoicePicker voices={voices} value={voiceId} onChange={setVoiceId} />
                {voice?.note ? (
                  <p className="text-muted-foreground text-xs">{voice.note}</p>
                ) : null}
              </div>
              <div className="flex flex-col gap-2">
                <Label>
                  Speed <span className="text-muted-foreground">{speed.toFixed(2)}×</span>
                </Label>
                <Slider
                  value={[speed]}
                  onValueChange={([v]) => setSpeed(v)}
                  min={0.7}
                  max={1.4}
                  step={0.05}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {busy ? (
              <Button onClick={stop} variant="destructive">
                <Square /> Stop
              </Button>
            ) : (
              <Button onClick={play} disabled={!voice || text.trim().length === 0}>
                <Play /> Play
              </Button>
            )}
            {status.state === 'connecting' ? (
              <span className="text-muted-foreground flex items-center gap-2 text-sm">
                <Loader2 className="size-4 animate-spin" /> synthesising…
              </span>
            ) : null}
            {status.state === 'error' ? (
              <span className="text-destructive text-sm">{status.message}</span>
            ) : null}
          </div>

          {status.state === 'done' ? <Stats result={status.result} /> : null}
        </CardContent>
      </Card>
    </div>
  )
}

function Stats({ result }: { result: SynthesisResult }) {
  const { trailer, clientTtfbMs, cancelled } = result
  const items = [
    { label: 'first audio (client)', value: `${Math.round(clientTtfbMs)} ms` },
    { label: 'ttfb (server)', value: `${Math.round(trailer.ttfb_ms)} ms` },
    { label: 'audio', value: `${(trailer.audio_ms / 1000).toFixed(1)} s` },
    { label: 'chars', value: String(trailer.chars) },
    { label: 'provider', value: trailer.provider },
  ]
  return (
    <dl className="text-muted-foreground flex flex-wrap gap-x-6 gap-y-1 border-t pt-3 text-xs">
      {items.map((item) => (
        <div key={item.label} className="flex gap-1.5">
          <dt>{item.label}:</dt>
          <dd className="text-foreground font-medium">{item.value}</dd>
        </div>
      ))}
      {cancelled ? <div className="text-destructive">cancelled</div> : null}
    </dl>
  )
}
