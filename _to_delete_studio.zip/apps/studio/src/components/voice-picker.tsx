import { Badge } from '#/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '#/components/ui/select'

import type { VoiceSpec } from '#/lib/tts'

export function VoicePicker({
  voices,
  value,
  onChange,
  className,
}: {
  voices: Array<VoiceSpec>
  value: string | undefined
  onChange: (voiceId: string) => void
  className?: string
}) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={className ?? 'w-full'}>
        <SelectValue placeholder="Pick a voice" />
      </SelectTrigger>
      <SelectContent>
        {voices.map((v) => (
          <SelectItem key={v.voice_id} value={v.voice_id}>
            <span className="flex items-center gap-2">
              {v.voice_id}
              <span className="text-muted-foreground text-xs">{v.language}</span>
              {v.grade ? (
                <Badge variant={v.grade === 'A' ? 'default' : 'secondary'}>{v.grade}</Badge>
              ) : null}
            </span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
