import { defineConfig } from 'vite'
import { devtools } from '@tanstack/devtools-vite'

import { tanstackStart } from '@tanstack/react-start/plugin/vite'

import viteReact from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// The studio talks to the model servers same-origin under /api/*; the dev
// server proxies to the host processes (`just tts`, `just stt`). This keeps
// CORS out of the Python services and lets the WS wire protocol pass through.
const TTS_URL = process.env.GOTINY_TTS_URL ?? 'http://127.0.0.1:8081'

const proxy = {
  '/api/tts': {
    target: TTS_URL,
    changeOrigin: true,
    ws: true,
    rewrite: (path: string) => path.replace(/^\/api\/tts/, ''),
  },
}

const config = defineConfig({
  resolve: { tsconfigPaths: true },
  server: { proxy },
  plugins: [devtools(), tailwindcss(), tanstackStart(), viteReact()],
})

export default config
