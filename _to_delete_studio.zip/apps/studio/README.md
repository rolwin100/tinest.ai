# gotiny studio

TanStack Start app: the creator studio for the podcast product. Three routes:

- **/** — Playground: live synthesis through the TTS server's wire protocol
  (WS `/v1/tts:stream`, binary PCM → Web Audio), voice picker fed by `/v1/caps`,
  client-measured first-audio latency next to the server's own TTFB.
- **/episodes** — multi-speaker script editor (blocks, one voice per block,
  live per-block preview). Whole-episode render is stubbed until the render
  pipeline (`services/worker`) lands in week B.
- **/voices** — the voice library from `/v1/caps`, plus the clone-your-voice
  shell (record/upload works; enrollment lands in week C).

## Run it

```sh
just tts      # terminal 1 — the model server (Kokoro & friends) on :8081
just studio   # terminal 2 — this app on :3000
```

Requires Node 22+ and pnpm (`corepack enable` gives you pnpm). First run:
`pnpm install` inside `apps/studio` (the `just studio` target does this).

## How it talks to the backend

Same-origin under `/api/tts/*`. The Vite dev server proxies that to the TTS
host process (default `http://127.0.0.1:8081`, override with `GOTINY_TTS_URL`),
WebSockets included — so the Python services need no CORS and the wire protocol
passes through untouched. `src/lib/tts.ts` is the protocol client and the PCM
player; it mirrors `packages/gotiny-providers` `wire.py` field for field. If
the wire changes, change both.

## Layout

```
src/
├── lib/tts.ts          # wire v1 client + gapless PCM player (the real work)
├── lib/queries.ts      # TanStack Query defs (caps)
├── routes/             # file-based routes: index (playground), episodes, voices
├── components/ui/      # hand-written shadcn-style primitives (registry was
│                       # unreachable from the authoring sandbox; these are standard)
└── components/voice-picker.tsx
```

Verified in the authoring sandbox against a stub wire-protocol server with
headless Chromium: caps → voice picker, Play → PCM chunks → trailer stats,
all three routes render. Not yet verified against the real Kokoro server —
that first run is yours.
